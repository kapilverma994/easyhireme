
import { BrowserRouter as Router } from "react-router-dom";

import { Routes } from './router';
import React,{useState,useEffect} from "react";
import './assets/css/custom.css';
import "slick-carousel/slick/slick-theme.css";

import "slick-carousel/slick/slick.css";

const App = () => {
  // const [size,setSize]=useState(window.innerWidth);
  // useEffect(() => {
  //   const handleResize= () =>{
  //     setSize(window.innerWidth)
  //   }
  //   window.addEventListener('resize',handleResize);
  

  //   return () => {
  // window.removeEventListener('resize',handleResize)
  //   }
  // }, [])


  // if(size<1300){
  //  return window.location.href = "https://m.easyhireme.com";
    
  // }
  return (
    <Router>
      <Routes />
    </Router>
  );
}
export default App;
