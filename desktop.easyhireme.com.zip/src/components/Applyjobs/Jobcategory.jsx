import React from "react";

export default function Jobcategory() {
  return (
    <>
      <div class="all-jobs">
        <h3>All Categories Jobs</h3>
        <p>Graphic Designer Jobs</p>
        <p>Engineering Jobs</p>
        <p>Mainframe Jobs</p>
        <p>Legal Jobs</p>
        <p>IT Jobs</p>
        <p>R&amp;D Jobs</p>
        <p>Government Jobs</p>
        <p>PSU Jobs</p>
        <p>Oil and Gas Jobs</p>
        <p>Pharma Jobs</p>
        <p>Telecom Jobs</p>
        <p>Media Jobs</p>
        <p>Automobile Jobs</p>
        <p>Insurance Jobs</p>
        <p>Bank Jobs</p>
        <p>Agriculture Jobs</p>
        <p>Defence Jobs</p>
        <p>NGO Jobs</p>
        <p>Shipping Jobs</p>
        <p>
          <a href="job-by-category.html">View all Categories</a>
        </p>
      </div>
    </>
  );
}
