import React from 'react'

export default function Banner() {
    return (
       
            <>
            <div className="easyhrie-banner">
			<img src="img/easyhire-banner.jpg" alt="easyhire-banner" className="responsive"/>
		</div>
            </>
      
    )
}
