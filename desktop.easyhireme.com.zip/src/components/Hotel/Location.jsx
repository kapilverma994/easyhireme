import React from "react";

const Location = () => {
  return (
    <div>
      <h3>No Content</h3>
    </div>
  );
};

export default Location;
