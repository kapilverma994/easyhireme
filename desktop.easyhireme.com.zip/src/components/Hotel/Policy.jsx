import React from "react";

const Policy = () => {
  return (
    <div>
      <h3>No Content</h3>
    </div>
  );
};

export default Policy;
