import React from "react";

const About = () => {
  return (
    <>
      <div id="aboutus">
        <h3>About Us</h3>
        <p>
          Phone number 02 6353763 Cuisines Indian, Rajasthani, Street Food,
          Chinese Average Cost AED 100 for two people (approx.) Cash and Cards
          accepted Opening hours � Open now Today 8am � 11:30pm Address Beside
          Bank of Baroda, Near Liwa Center, Hamdan Street, Al Markaziya, Abu
          Dhabi See 3 more locations � Royal Rajasthan address, Royal Rajasthan
          location Get Directions More Info Breakfast Home Delivery Vegetarian
          Only No Alcohol Available Indoor Seating Known For Authentic
          Rajasthani fare made using traditional recipes. Report Error Claimed
          listing
        </p>
      </div>
    </>
  );
};

export default About;
