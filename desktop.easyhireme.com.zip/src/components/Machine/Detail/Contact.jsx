import React from "react";

const Contact = () => {
  return (
    <>
      <h3>Contact Us</h3>
    </>
  );
};

export default Contact;
