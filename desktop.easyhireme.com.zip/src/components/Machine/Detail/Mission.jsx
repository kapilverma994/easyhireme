import React from "react";

const Mission = () => {
  return (
    <div>
      <h3>Our Mission</h3>
    </div>
  );
};

export default Mission;
