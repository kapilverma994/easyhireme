import React from "react";

const Service = () => {
  return (
    <div>
      <h3>Services</h3>
    </div>
  );
};

export default Service;
