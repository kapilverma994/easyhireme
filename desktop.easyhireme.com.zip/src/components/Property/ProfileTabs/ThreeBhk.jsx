import React from "react";

const ThreeBhk = () => {
  return (
    <div>
      <p>
        Sed ut perspiciatis unde omnis iste natus error sit voluptatem
        accusantium doloremque laudantium, totam rem aperiam.
      </p>
    </div>
  );
};

export default ThreeBhk;
