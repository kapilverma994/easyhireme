const config = {
    appName: 'Demo',
}

export default config;