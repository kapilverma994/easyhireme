export { default as withAuthentication } from './withAuthentication';
