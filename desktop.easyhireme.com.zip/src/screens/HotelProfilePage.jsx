import React from "react";

import HotelDetail from "../components/Hotel/HotelDetail";

const HotelProfilePage = () => {
  return (
    <div>
      <HotelDetail />
    </div>
  );
};

export default HotelProfilePage;
